/**
 * Arrakis Manager Console Addon Controller
 */

// Security Utils
const escapeHTML = (str) => {
  if (str == null) return '';
  return String(str).replace(/[&<>'"]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[tag]));
};

// Tab Navigation elements
const tabSettingsBtn = document.getElementById('tabSettingsBtn');
const settingsView = document.getElementById('settingsView');
const connectionStatusBadge = document.getElementById('connectionStatusBadge');

// Multipliers settings inputs

const playtimeIntervalSlider = document.getElementById('playtimeIntervalSlider');
const playtimeIntervalInput = document.getElementById('playtimeIntervalInput');
const playtimeDistanceSlider = document.getElementById('playtimeDistanceSlider');
const playtimeDistanceInput = document.getElementById('playtimeDistanceInput');
const playtimeXpSlider = document.getElementById('playtimeXpSlider');
const playtimeXpInput = document.getElementById('playtimeXpInput');

// Online Diagnostics and Pending Queue
const diagnosticsTableBody = document.getElementById('diagnosticsTableBody');
const pendingAirdropsTableBody = document.getElementById('pendingAirdropsTableBody');
const airdropPlayerSelect = document.getElementById('airdropPlayerSelect');
const deliverySummary = document.getElementById('deliverySummary');

let pendingAirdropsData = [];
let activeContainerId = null;

// Determine if running inside the Dune Docker Console iframe
const isSandboxMode = window.parent === window;

// --- Initialize Bridge & UI ---

document.addEventListener('DOMContentLoaded', async () => {
  setupMultipliersSync();

  const clearQueueBtn = document.getElementById('clearQueueBtn');
  if (clearQueueBtn) {
    clearQueueBtn.addEventListener('click', () => showToast('Queue deletion is disabled. Review individual historical rewards instead.', 'warning'));
  }

  if (isSandboxMode) {
    connectionStatusBadge.textContent = 'Bridge Sandbox';
    connectionStatusBadge.className = connectionStatusBadge.className.replace('text-amber-500', 'text-amber-400');
    loadMockData();
  } else {
    connectionStatusBadge.textContent = 'Console Connected';
    connectionStatusBadge.className = connectionStatusBadge.className.replace('bg-amber-500/10 text-amber-500', 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20');

    const schemaReady = await isAirdropSchemaReady();
    if (schemaReady) {
      await loadSettings();
      await fetchDiagnostics();
      await fetchPendingAirdrops();
      await fetchDeliverySummary();
      await fetchContainers();

      window.__fetchDiagnosticsInterval = setInterval(fetchDiagnostics, 5000);
      window.__fetchPendingInterval = setInterval(fetchPendingAirdrops, 5000);
      window.__fetchDeliveryInterval = setInterval(fetchDeliverySummary, 5000);
    } else {
      connectionStatusBadge.textContent = 'Setup Required';
      connectionStatusBadge.className = connectionStatusBadge.className.replace(
        'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
        'bg-amber-500/10 text-amber-400 border-amber-500/20'
      );
      showToast('Database setup is required. Click INIT SCHEMA to finish installing Airdrop Manager.', 'warning');
    }

    // Wire up the manual spawn modal
    setupSpawnModal();

    // Wire up tabs
    const settingsTab = document.getElementById('tabSettingsBtn');
    const lootTab = document.getElementById('tabLootBtn');
    const settingsView = document.getElementById('settingsView');
    const lootView = document.getElementById('lootView');

    if (settingsTab && lootTab && settingsView && lootView) {
      settingsTab.addEventListener('click', () => {
        settingsView.classList.remove('hidden');
        lootView.classList.add('hidden');
        settingsTab.classList.replace('bg-slate-800', 'bg-amber-500');
        settingsTab.classList.replace('text-slate-300', 'text-slate-950');
        settingsTab.classList.add('neon-glow-orange');
        settingsTab.classList.remove('hover:bg-slate-700');

        lootTab.classList.replace('bg-amber-500', 'bg-slate-800');
        lootTab.classList.replace('text-slate-950', 'text-slate-300');
        lootTab.classList.remove('neon-glow-orange');
        lootTab.classList.add('hover:bg-slate-700');
      });

      lootTab.addEventListener('click', () => {
        lootView.classList.remove('hidden');
        settingsView.classList.add('hidden');
        lootTab.classList.replace('bg-slate-800', 'bg-amber-500');
        lootTab.classList.replace('text-slate-300', 'text-slate-950');
        lootTab.classList.add('neon-glow-orange');
        lootTab.classList.remove('hover:bg-slate-700');

        settingsTab.classList.replace('bg-amber-500', 'bg-slate-800');
        settingsTab.classList.replace('text-slate-950', 'text-slate-300');
        settingsTab.classList.remove('neon-glow-orange');
        settingsTab.classList.add('hover:bg-slate-700');
      });
    }
  }
});

// --- Multipliers Sync Bindings ---
function setupMultipliersSync() {
  const syncRangeAndNumber = (slider, input, min, max, step) => {
    if (!slider || !input) return;
    slider.addEventListener('input', () => {
      input.value = slider.value;
    });
    input.addEventListener('input', () => {
      let val = parseFloat(input.value) || min;
      val = Math.max(min, Math.min(max, val));
      slider.value = val;
    });
  };

  syncRangeAndNumber(playtimeIntervalSlider, playtimeIntervalInput, 1, 120, 1);
  syncRangeAndNumber(playtimeDistanceSlider, playtimeDistanceInput, 0, 100, 1);
  syncRangeAndNumber(playtimeXpSlider, playtimeXpInput, 0, 1000, 5);

  // Sync Daily and Weekly sliders
  syncRangeAndNumber(document.getElementById('dailyStepSlider'), document.getElementById('dailyStepInput'), 0.1, 10, 0.1);
  syncRangeAndNumber(document.getElementById('dailyMaxStreakSlider'), document.getElementById('dailyMaxStreakInput'), 1, 30, 1);
  syncRangeAndNumber(document.getElementById('weeklyDaysRequiredSlider'), document.getElementById('weeklyDaysRequiredInput'), 1, 7, 1);
  syncRangeAndNumber(document.getElementById('weeklyMultiplierSlider'), document.getElementById('weeklyMultiplierInput'), 1, 100, 0.5);


  // Sync Economy Sliders
  syncRangeAndNumber(document.getElementById('probGearSlider'), document.getElementById('probGearInput'), 0, 100, 1);
  syncRangeAndNumber(document.getElementById('probSchemSlider'), document.getElementById('probSchemInput'), 0, 100, 1);
  syncRangeAndNumber(document.getElementById('probCraftSlider'), document.getElementById('probCraftInput'), 0, 100, 1);
  syncRangeAndNumber(document.getElementById('probRawSlider'), document.getElementById('probRawInput'), 0, 100, 1);
  syncRangeAndNumber(document.getElementById('minItemsSlider'), document.getElementById('minItemsInput'), 0, 4, 1);

  // Sync Tier Multipliers
  for (let t = 0; t <= 6; t++) {
    const slider = document.getElementById(`playtimeMultiplierT${t}Slider`);
    const input = document.getElementById(`playtimeMultiplierT${t}Input`);
    syncRangeAndNumber(slider, input, 1, 100, 1);
  }
}

// --- Spawn Modal Logic ---
function setupSpawnModal() {
  const spawnItemModal = document.getElementById('spawnItemModal');
  const spawnItemCancelBtn = document.getElementById('spawnItemCancelBtn');
  const spawnItemConfirmBtn = document.getElementById('spawnItemConfirmBtn');
  const spawnItemTemplateInput = document.getElementById('spawnItemTemplateInput');
  const spawnItemQtyInput = document.getElementById('spawnItemQtyInput');
  const openSpawnModalBtn = document.getElementById('openSpawnModalBtn');
  const validItemTemplates = document.getElementById('validItemTemplates');
  const discardBtn = document.getElementById('spawnItemDiscardBtn');
  const warningText = document.getElementById('spawnItemWarningText');

  function updateUncertainStateUI(isUncertain) {
    if (isUncertain) {
      spawnItemTemplateInput.disabled = true;
      spawnItemQtyInput.disabled = true;
      if (discardBtn) discardBtn.classList.remove('hidden');
      if (warningText) warningText.classList.remove('hidden');
    } else {
      spawnItemTemplateInput.disabled = false;
      spawnItemQtyInput.disabled = false;
      if (discardBtn) discardBtn.classList.add('hidden');
      if (warningText) warningText.classList.add('hidden');
    }
  }

  function handleStateCheck() {
    const currentState = getStoredGrantState(window.localStorage);
    if (currentState) {
      // Lock inputs to the stored payload
      spawnItemTemplateInput.value = currentState.payload.itemId;
      spawnItemQtyInput.value = currentState.payload.quantity;
      spawnItemTemplateInput.dataset.actId = currentState.payload.containerId;
      if (activeContainerId !== currentState.payload.containerId) {
        window.selectContainer(currentState.payload.containerId, true);
      }
      updateUncertainStateUI(true);
    } else {
      updateUncertainStateUI(false);
    }
  }

  if (discardBtn) {
    discardBtn.addEventListener('click', () => {
      clearStoredGrantState(window.localStorage);
      updateUncertainStateUI(false);
      showToast('Uncertain delivery state discarded.', 'success');
    });
  }

  spawnItemCancelBtn.addEventListener('click', () => {
    spawnItemModal.classList.add('hidden');
    // We do NOT clear the state here if it was in flight or uncertain!
    // The pure functions handle state clearing.
  });

  // Global selectContainer implementation
  window.selectContainer = async function(id, skipStateCheck = false) {
    if (!/^[0-9]+$/.test(String(id))) {
      showToast('Invalid container ID selected.', 'error');
      return;
    }
    activeContainerId = String(id);
    spawnItemTemplateInput.dataset.actId = activeContainerId;

    // Update UI highlights
    const rows = document.querySelectorAll('.container-row');
    rows.forEach(r => r.classList.remove('bg-amber-900/30', 'border-amber-500/50'));
    const selectedRow = document.getElementById(`container-row-${id}`);
    if (selectedRow) {
      selectedRow.classList.add('bg-amber-900/30', 'border-amber-500/50');
    }

    if (openSpawnModalBtn) openSpawnModalBtn.classList.remove('hidden');

    // Clear container grid to show it is selected
    const grid = document.getElementById('containerInventoryGrid');
    if (grid) {
      grid.innerHTML = `<div class="col-span-full py-12 text-center text-slate-500 font-mono italic">
        Container ${escapeHTML(id)} selected. Ready to spawn items.
      </div>`;
    }

    if (!skipStateCheck) {
      handleStateCheck();
    }
  };

  if (openSpawnModalBtn) {
    openSpawnModalBtn.addEventListener('click', () => {
      spawnItemModal.classList.remove('hidden');
    });
  }

  spawnItemConfirmBtn.addEventListener('click', async () => {
    const templateId = spawnItemTemplateInput.value.trim();
    const qty = Number(spawnItemQtyInput.value);

    if (!/^[A-Za-z0-9_./:-]{1,240}$/.test(templateId)) {
      showToast('Enter a valid item template ID.', 'error');
      return;
    }
    if (!Number.isInteger(qty) || qty < 1 || qty > 1000) {
      showToast('Quantity must be a whole number from 1 to 1000.', 'error');
      return;
    }

    // Disable submission immediately to prevent duplicate rapid clicks
    spawnItemConfirmBtn.disabled = true;
    spawnItemConfirmBtn.textContent = 'SPAWNING...';

    if (isSandboxMode) {
      showToast(`Mock: Spawned ${qty}x ${templateId}`, 'success');
      spawnItemModal.classList.add('hidden');
      spawnItemConfirmBtn.disabled = false;
      spawnItemConfirmBtn.textContent = 'SPAWN';
      return;
    }

    try {
      const actId = String(spawnItemTemplateInput.dataset.actId || activeContainerId);
      if (!/^[0-9]+$/.test(actId)) {
        throw new Error("Invalid container ID format");
      }
      const qNum = qty;

      // Resolve actId to FLS account_id securely with bigint cast
      const res = await window.DuneAddon.request("database.query", {
        query: `SELECT account_id FROM dune.inventories WHERE id = ${actId}::bigint LIMIT 1`
      });

      const account_id = (res.rows && res.rows.length === 1 && res.rows[0] && res.rows[0].account_id) ? String(res.rows[0].account_id) : null;

      if (!account_id || account_id.trim() === '') {
        throw new Error("Could not resolve exactly one nonempty player account.");
      }

      const newPayload = {
        playerId: account_id,
        itemId: templateId,
        quantity: qNum,
        quality: 0,
        containerId: actId
      };

      const currentState = getStoredGrantState(window.localStorage);
      const stateDecision = determineActionAndState(currentState, newPayload, window.crypto);

      if (stateDecision.action === 'REJECT_UNCERTAIN') {
        showToast('A previous delivery is in an uncertain state. You must retry it or discard it first.', 'error');
        spawnItemConfirmBtn.disabled = false;
        spawnItemConfirmBtn.textContent = 'SPAWN';
        return;
      }

      // Persist pending/uncertain state before calling bridge
      setStoredGrantState(stateDecision.newState, window.localStorage);

      const payload = {
        ...stateDecision.newState.payload,
        requestId: stateDecision.newState.id
      };

      const receipt = await window.DuneAddon.request("admin.items.grant", payload);

      const outcome = handleBridgeReceipt(receipt, stateDecision.newState, window.localStorage);

      if (outcome.success) {
        showToast(`Successfully spawned ${qNum}x ${templateId}`, 'success');
        updateUncertainStateUI(false);
        if (window.selectContainer) {
          await window.selectContainer(actId);
        }
        spawnItemModal.classList.add('hidden');
      } else {
        throw new Error(outcome.message);
      }
    } catch (err) {
      if (isAmbiguousBridgeError(err)) {
        showToast(`Failed to spawn item: ${err.message}`, 'error');
        const currentState = getStoredGrantState(window.localStorage);
        if (currentState) {
          currentState.status = 'UNCERTAIN';
          setStoredGrantState(currentState, window.localStorage);
        }
        handleStateCheck();
      } else {
        handlePermanentRejection(null, window.localStorage);
        updateUncertainStateUI(false);
        showToast(`Spawn request rejected: ${err.message}`, 'error');
      }
    } finally {
      spawnItemConfirmBtn.disabled = false;
      spawnItemConfirmBtn.textContent = 'SPAWN';
    }
  });

  const commonItems = ['ScrapMetal', 'CopperOre', 'IronOre', 'FlourSand', 'PlantFiber', 'Basalt', 'DolomiteRock', 'Silicone', 'WaterCanister', 'SpiceMelange'];
  validItemTemplates.innerHTML = commonItems.map(item => `<option value="${item}"></option>`).join('');

  handleStateCheck();
}


// --- Database Operations ---
async function isAirdropSchemaReady() {
  try {
    const rawResult = await window.DuneAddon.request("database.query", {
      query: `SELECT
                to_regclass('dune_airdrop.config')::text AS config_table,
                to_regclass('dune_airdrop.active_playtime')::text AS playtime_table,
                to_regclass('dune_airdrop.pending_deliveries')::text AS queue_table`
    });
    const rows = rawResult.rows || rawResult || [];
    const row = rows[0] || {};
    return Boolean(row.config_table && row.playtime_table && row.queue_table);
  } catch (err) {
    showToast(`Failed to check database setup: ${err.message}`, 'error');
    return false;
  }
}

async function loadSettings() {
  try {
    const rawRes = await window.DuneAddon.request("database.query", {
      query: "SELECT config_value FROM dune_airdrop.config WHERE config_key = 'airdrop_multipliers' LIMIT 1"
    });
    const res = rawRes.rows || rawRes || [];

    let mults = {
      playtime_enabled: true,
      playtime_interval: 60,
      playtime_distance: 10,
      playtime_xp: 1,
      daily_enabled: true,
      daily_multiplier_step: 0.5,
      daily_max_streak: 7,
      weekly_enabled: true,
      weekly_days_required: 5,
      weekly_multiplier: 5.0,
      daemon_enabled: true
    };
    if (res && res.length > 0 && res[0].config_value) {
      mults = { ...mults, ...res[0].config_value };
    }

    // Load playtime inputs
    document.getElementById('playtimeEnabledToggle').checked = mults.playtime_enabled !== undefined ? mults.playtime_enabled : true;
    playtimeIntervalInput.value = mults.playtime_interval || 60;
    playtimeIntervalSlider.value = mults.playtime_interval || 60;
    playtimeDistanceInput.value = mults.playtime_distance !== undefined ? mults.playtime_distance : 10.0;
    playtimeDistanceSlider.value = mults.playtime_distance !== undefined ? mults.playtime_distance : 10.0;
    playtimeXpInput.value = mults.playtime_xp !== undefined ? mults.playtime_xp : 1;
    playtimeXpSlider.value = mults.playtime_xp !== undefined ? mults.playtime_xp : 1;
    const daemonToggle = document.getElementById('daemonEnabledToggle');
    if (daemonToggle) {
      daemonToggle.checked = mults.daemon_enabled !== undefined ? mults.daemon_enabled : true;
    }

    // Load Daily inputs
    document.getElementById('dailyEnabledToggle').checked = mults.daily_enabled !== undefined ? mults.daily_enabled : true;
    document.getElementById('dailyStepInput').value = mults.daily_multiplier_step !== undefined ? mults.daily_multiplier_step : 0.5;
    document.getElementById('dailyStepSlider').value = mults.daily_multiplier_step !== undefined ? mults.daily_multiplier_step : 0.5;
    document.getElementById('dailyMaxStreakInput').value = mults.daily_max_streak !== undefined ? mults.daily_max_streak : 7;
    document.getElementById('dailyMaxStreakSlider').value = mults.daily_max_streak !== undefined ? mults.daily_max_streak : 7;

    // Load Weekly inputs
    document.getElementById('weeklyEnabledToggle').checked = mults.weekly_enabled !== undefined ? mults.weekly_enabled : true;
    document.getElementById('weeklyDaysRequiredInput').value = mults.weekly_days_required !== undefined ? mults.weekly_days_required : 5;
    document.getElementById('weeklyDaysRequiredSlider').value = mults.weekly_days_required !== undefined ? mults.weekly_days_required : 5;
    document.getElementById('weeklyMultiplierInput').value = mults.weekly_multiplier !== undefined ? mults.weekly_multiplier : 5.0;
    document.getElementById('weeklyMultiplierSlider').value = mults.weekly_multiplier !== undefined ? mults.weekly_multiplier : 5.0;


    const rawResEcon = await window.DuneAddon.request("database.query", {
      query: "SELECT config_value FROM dune_airdrop.config WHERE config_key = 'airdrop_economy' LIMIT 1"
    });
    const resEcon = rawResEcon.rows || rawResEcon || [];
    let econ = {
      prob_gear: 0.40, prob_schem: 0.80, prob_raw: 1.0, prob_craft: 1.0, min_items: 1,
      tier_0_min: 5, tier_0_max: 10,
      tier_1_min: 5, tier_1_max: 15,
      tier_2_min: 10, tier_2_max: 25,
      tier_3_min: 15, tier_3_max: 35,
      tier_4_min: 20, tier_4_max: 50,
      tier_5_min: 30, tier_5_max: 75,
      tier_6_min: 50, tier_6_max: 100
    };
    if (resEcon && resEcon.length > 0 && resEcon[0].config_value) {
      econ = { ...econ, ...resEcon[0].config_value };
    }

    // Load Economy inputs
    document.getElementById('probGearInput').value = Math.round(econ.prob_gear * 100);
    document.getElementById('probGearSlider').value = Math.round(econ.prob_gear * 100);
    document.getElementById('probSchemInput').value = Math.round(econ.prob_schem * 100);
    document.getElementById('probSchemSlider').value = Math.round(econ.prob_schem * 100);
    document.getElementById('probCraftInput').value = Math.round(econ.prob_craft * 100);
    document.getElementById('probCraftSlider').value = Math.round(econ.prob_craft * 100);
    document.getElementById('probRawInput').value = Math.round(econ.prob_raw * 100);
    document.getElementById('probRawSlider').value = Math.round(econ.prob_raw * 100);
    document.getElementById('minItemsInput').value = econ.min_items;
    document.getElementById('minItemsSlider').value = econ.min_items;

    for (let t = 0; t <= 6; t++) {
      const minInput = document.getElementById(`t${t}MinInput`);
      const maxInput = document.getElementById(`t${t}MaxInput`);
      if (minInput) minInput.value = econ[`tier_${t}_min`] || 1;
      if (maxInput) maxInput.value = econ[`tier_${t}_max`] || 1;
    }

    for (let t = 0; t <= 6; t++) {
      const input = document.getElementById(`playtimeMultiplierT${t}Input`);
      const slider = document.getElementById(`playtimeMultiplierT${t}Slider`);
      if (input && slider) {
        const val = mults[`playtime_multiplier_t${t}`] !== undefined ? mults[`playtime_multiplier_t${t}`] : (mults.playtime_multiplier || 1);
        input.value = val;
        slider.value = Math.min(50, val);
      }
    }

  } catch (err) {
    showToast(`Failed to load settings: ${err.message}`, 'error');
  }
}

async function handleSaveAllSettings() {
  if (isSandboxMode) {
    showToast('Mock: Settings saved successfully!', 'success');
    return;
  }

  try {
    const getFloat = (val, def) => { const n = parseFloat(val); return isNaN(n) ? def : n; };
    const getInt = (val, def) => { const n = parseInt(val); return isNaN(n) ? def : n; };

    const payload = {
      playtime_enabled: document.getElementById('playtimeEnabledToggle').checked,
      playtime_interval: getInt(playtimeIntervalInput.value, 60),
      playtime_distance: getFloat(playtimeDistanceInput.value, 10.0),
      playtime_xp: getInt(playtimeXpInput.value, 1),
      daily_enabled: document.getElementById('dailyEnabledToggle').checked,
      daily_multiplier_step: getFloat(document.getElementById('dailyStepInput').value, 0.5),
      daily_max_streak: getInt(document.getElementById('dailyMaxStreakInput').value, 7),
      weekly_enabled: document.getElementById('weeklyEnabledToggle').checked,
      weekly_days_required: getInt(document.getElementById('weeklyDaysRequiredInput').value, 5),
      weekly_multiplier: getFloat(document.getElementById('weeklyMultiplierInput').value, 5.0),
      daemon_enabled: document.getElementById('daemonEnabledToggle') ? document.getElementById('daemonEnabledToggle').checked : true
    };

    for (let t = 0; t <= 6; t++) {
      const input = document.getElementById(`playtimeMultiplierT${t}Input`);
      payload[`playtime_multiplier_t${t}`] = input ? getInt(input.value, 1) : 1;
    }
    payload.playtime_multiplier = payload.playtime_multiplier_t6;


    const econPayload = {
      prob_gear: getFloat(document.getElementById('probGearInput').value, 40) / 100,
      prob_schem: getFloat(document.getElementById('probSchemInput').value, 80) / 100,
      prob_craft: getFloat(document.getElementById('probCraftInput').value, 100) / 100,
      prob_raw: getFloat(document.getElementById('probRawInput').value, 100) / 100,
      min_items: Math.max(0, Math.min(4, getInt(document.getElementById('minItemsInput').value, 1))),
    };
    for (let t = 0; t <= 6; t++) {
      econPayload[`tier_${t}_min`] = getInt(document.getElementById(`t${t}MinInput`).value, 1);
      econPayload[`tier_${t}_max`] = getInt(document.getElementById(`t${t}MaxInput`).value, 1);
    }

    const escapedEconJson = JSON.stringify(econPayload).replace(/'/g, "''");
    await window.DuneAddon.request("database.execute", {
      query: `INSERT INTO dune_airdrop.config (config_key, config_value)
              VALUES ('airdrop_economy', '${escapedEconJson}'::jsonb)
              ON CONFLICT (config_key)
              DO UPDATE SET config_value = EXCLUDED.config_value`
    });

    // 1. Save Airdrops Config
    const escapedJson = JSON.stringify(payload).replace(/'/g, "''");
    await window.DuneAddon.request("database.execute", {
      query: `INSERT INTO dune_airdrop.config (config_key, config_value)
              VALUES ('airdrop_multipliers', '${escapedJson}'::jsonb)
              ON CONFLICT (config_key)
              DO UPDATE SET config_value = EXCLUDED.config_value`
    });

    showToast('All multipliers and settings saved successfully!', 'success');
  } catch (err) {
    showToast(`Failed to save settings: ${err.message}`, 'error');
  }
}

async function handleInitializeSchema() {
  if (isSandboxMode) {
    showToast('Mock: Database schema initialized successfully!', 'success');
    return;
  }

  const confirmed = window.confirm(
    'Stop the battlegroup before initializing or upgrading Airdrop Manager. ' +
    'This briefly replaces its player-state trigger. Continue now?'
  );
  if (!confirmed) return;

  try {
    showToast('Loading SQL schema from addon package...', 'success');
    const response = await fetch('../setup_playtime_airdrops.sql');
    if (!response.ok) throw new Error('Failed to fetch SQL file.');

    const sqlQuery = await response.text();

    showToast('Executing schema creation... This may take a moment.', 'success');
    await window.DuneAddon.request("database.execute", {
      query: sqlQuery
    });

    showToast('Database schema and triggers initialized successfully. Reloading...', 'success');
    window.setTimeout(() => window.location.reload(), 500);
  } catch (err) {
    const message = String(err?.message || err);
    if (/lock timeout|statement timeout|canceling statement/i.test(message)) {
      showToast('Schema init could not lock the active player-state table. Stop the battlegroup, then click INIT SCHEMA again.', 'error');
    } else {
      showToast(`Schema init failed: ${message}`, 'error');
    }
  }
}

async function fetchDiagnostics() {
  if (isSandboxMode) return;

  try {
    const rawPlayers = await window.DuneAddon.request("database.query", {
      query: `SELECT
                ps.character_name AS name,
                ps.player_pawn_id AS character_id,
                COALESCE(act.map, 'Unknown') AS map,
                COALESCE(bp.active_seconds, 0) AS active_seconds,
                COALESCE(bp.consecutive_days, 0) AS consecutive_days,
                COALESCE(bp.weekly_login_mask, 0) AS weekly_login_mask
              FROM dune.player_state ps
              LEFT JOIN dune.actors act ON ps.player_pawn_id = act.id
              LEFT JOIN dune_airdrop.active_playtime bp ON ps.player_pawn_id = bp.character_id::bigint
              WHERE ps.player_pawn_id IS NOT NULL AND LOWER(ps.online_status::text) = 'online'`
    });
    const players = rawPlayers.rows || rawPlayers || [];

    if (!players || players.length === 0) {
      diagnosticsTableBody.innerHTML = `
        <tr>
          <td colspan="7" class="py-4 text-center italic text-slate-500">No online players detected.</td>
        </tr>
      `;
      return;
    }

    diagnosticsTableBody.innerHTML = players.map(p => {
      const characterId = String(p.character_id || '');
      const hasValidCharacterId = /^[0-9]+$/.test(characterId);
      const activeMin = Math.floor(p.active_seconds / 60);
      const limitMin = parseInt(playtimeIntervalInput.value) || 60;
      const nextMin = Math.max(0, limitMin - activeMin);

      const weeklyLogins = (p.weekly_login_mask || 0).toString(2).split('1').length - 1;
      const weeklyReq = parseInt(document.getElementById('weeklyDaysRequiredInput').value) || 5;

      return `
        <tr class="border-b border-slate-900/40 hover:bg-slate-900/20 font-mono">
          <td class="py-2 text-slate-300">${escapeHTML(p.name)}</td>
          <td class="py-2 text-slate-400">${activeMin}m / ${limitMin}m</td>
          <td class="py-2 text-slate-400">${nextMin}m left</td>
          <td class="py-2 text-slate-400">${p.consecutive_days || 0} Days</td>
          <td class="py-2 text-slate-400">${weeklyLogins} / ${weeklyReq}</td>
          <td class="py-2 text-right text-slate-500">${escapeHTML(p.map)}</td>
          <td class="py-2 text-right">
            ${hasValidCharacterId ? `<button onclick="testResetDaily('${characterId}')" class="text-[10px] bg-red-900/40 hover:bg-red-800 text-red-200 px-2 py-1 rounded">Reset Daily</button>
            <button onclick="testSetWeekly('${characterId}')" class="text-[10px] bg-blue-900/40 hover:bg-blue-800 text-blue-200 px-2 py-1 rounded ml-1">Set 5/5</button>` : '-'}
          </td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    console.error('Diagnostics failed:', err);
  }
}

async function fetchPendingAirdrops() {
  if (isSandboxMode) return;

  try {
    const rawList = await window.DuneAddon.request("database.query", {
      query: `SELECT bpd.id, COALESCE(ps.character_name, 'Unknown') as character_name, bpd.template_id, bpd.stack_size,
                     COALESCE(bpd.delivery_state, CASE WHEN bpd.is_applied THEN 'DELIVERED' ELSE 'PENDING' END) AS delivery_state,
                     COALESCE(bpd.requires_recovery_approval, false) AS requires_recovery_approval,
                     bpd.last_error_code, bpd.next_attempt_at
              FROM dune_airdrop.pending_deliveries bpd
              LEFT JOIN dune.player_state ps ON bpd.account_id = ps.account_id
              WHERE bpd.is_applied = false AND COALESCE(to_jsonb(bpd)->>'resolution_status', '') = ''
              ORDER BY bpd.created_at DESC
              LIMIT 500`
    });
    const list = rawList.rows || rawList || [];

    pendingAirdropsData = list || [];
    renderPendingAirdrops();

    // Populate filter dropdown
    const selected = airdropPlayerSelect.value;
    const names = [...new Set(pendingAirdropsData.map(d => d.character_name))].sort();
    airdropPlayerSelect.innerHTML = '<option value="all">All Characters</option>' +
      names.map(n => `<option value="${escapeHTML(n)}">${escapeHTML(n)}</option>`).join('');
    if (names.includes(selected) || selected === 'all') {
      airdropPlayerSelect.value = selected;
    }
  } catch (err) {
    console.error('Failed to load pending queue:', err);
    pendingAirdropsTableBody.innerHTML = `
      <tr>
        <td colspan="3" class="py-4 text-center italic text-rose-500">Error: ${escapeHTML(err.message || String(err))}</td>
      </tr>
    `;
  }
}

function renderPendingAirdrops() {
  const filter = airdropPlayerSelect.value;
  const filtered = filter === 'all'
    ? pendingAirdropsData
    : pendingAirdropsData.filter(d => d.character_name === filter);

  if (filtered.length === 0) {
    pendingAirdropsTableBody.innerHTML = `
      <tr>
        <td colspan="3" class="py-2 text-center italic text-slate-500">No pending airdrops.</td>
      </tr>
    `;
    return;
  }

  pendingAirdropsTableBody.innerHTML = filtered.map(d => `
    <tr class="border-b border-slate-900/40 hover:bg-slate-900/20 font-mono text-xs">
      <td class="py-1.5 text-slate-300">${escapeHTML(d.character_name)}</td>
      <td class="py-1.5 text-amber-500 font-bold">${escapeHTML(d.template_id)}</td>
      <td class="py-1.5 text-right text-slate-300 font-bold">${d.stack_size} <span class="text-slate-500">${escapeHTML(d.delivery_state)}</span><button onclick="window.openDeliveryHistory('${escapeHTML(d.id)}')" class="ml-1 text-sky-400 underline">history</button>${d.requires_recovery_approval && d.delivery_state === 'WAITING_FOR_PLAYER' ? ` <button onclick="window.approveHistoricalDelivery('${escapeHTML(d.id)}')" class="ml-1 text-amber-400 underline">review</button>` : ''}${d.delivery_state === 'UNCERTAIN' ? ` <button onclick="window.openDeliveryResolution('${escapeHTML(d.id)}')" class="ml-1 text-rose-300 underline">resolve</button>` : ''}</td>
    </tr>
  `).join('');
}

async function fetchDeliverySummary() {
  if (isSandboxMode || !deliverySummary) return;
  try {
    const raw = await window.DuneAddon.request('database.query', { query: `
      SELECT delivery_state, count(*)::int AS count FROM dune_airdrop.pending_deliveries GROUP BY delivery_state
      UNION ALL SELECT 'PENDING_RECEIPTS', count(*)::int FROM dune_airdrop.delivery_receipts WHERE status = 'PENDING'
      UNION ALL SELECT 'DAEMON_HEARTBEAT', 0` });
    const rows = raw.rows || raw || [];
    const values = Object.fromEntries(rows.map(row => [row.delivery_state, row.count]));
    deliverySummary.innerHTML = ['READY', 'WAITING_FOR_PLAYER', 'DELIVERING', 'DELIVERED', 'FAILED', 'UNCERTAIN', 'LEGACY_REVIEW', 'PENDING_RECEIPTS']
      .map(key => `<div class="rounded border border-slate-800 p-2"><span class="block text-slate-500">${escapeHTML(key.replaceAll('_', ' '))}</span><strong>${escapeHTML(values[key] || 0)}</strong></div>`).join('');
  } catch (error) {
    deliverySummary.textContent = `Delivery lifecycle status unavailable: ${error.message || error}`;
  }
}

window.approveHistoricalDelivery = async function(id) {
  if (!/^\d+$/.test(String(id))) return;
  if (!window.confirm('Approve this one historical reward only after confirming it was never delivered? Uncertain deliveries must not be approved.')) return;
  try {
    const result = await window.DuneAddon.request('database.execute', { query: `WITH approved AS (UPDATE dune_airdrop.pending_deliveries SET requires_recovery_approval = false, recovery_approved_at = NOW(), updated_at = NOW() WHERE id = ${id}::int AND delivery_state = 'WAITING_FOR_PLAYER' AND requires_recovery_approval = true RETURNING id) INSERT INTO dune_airdrop.delivery_events (delivery_id, state, detail) SELECT id, 'WAITING_FOR_PLAYER', 'Historical recovery approved by administrator.' FROM approved;` });
    if (Number(result?.rowCount || 0) !== 1) throw new Error('Reward is no longer eligible for recovery approval. Refresh and review its current state.');
    showToast('Historical reward approved for normal offline-aware delivery.', 'success'); fetchPendingAirdrops(); fetchDeliverySummary();
  } catch (error) { showToast(`Recovery approval failed: ${error.message || error}`, 'error'); }
};

let selectedDeliveryId = null;
const deliveryHistoryBody = document.getElementById('deliveryHistoryBody');
const deliveryResolutionModal = document.getElementById('deliveryResolutionModal');
const deliveryResolutionTitle = document.getElementById('deliveryResolutionTitle');

window.openDeliveryHistory = async function(id) {
  if (!/^\d+$/.test(String(id))) return;
  try {
    const raw = await window.DuneAddon.request('database.query', { query: `SELECT e.created_at, e.state, e.detail FROM dune_airdrop.delivery_events e WHERE e.delivery_id = ${id}::int ORDER BY e.created_at DESC LIMIT 100` });
    const rows = raw.rows || raw || [];
    deliveryHistoryBody.innerHTML = rows.length ? rows.map(row => `<tr><td class="py-1 pr-2 text-slate-500">${escapeHTML(row.created_at)}</td><td class="py-1 pr-2 text-amber-400">${escapeHTML(row.state)}</td><td class="py-1 text-slate-300 break-all">${escapeHTML(row.detail)}</td></tr>`).join('') : '<tr><td class="py-3 text-slate-500" colspan="3">No addon event history exists for this delivery.</td></tr>';
    document.getElementById('deliveryHistoryModal').classList.remove('hidden');
  } catch (error) { showToast(`Failed to load delivery history: ${error.message || error}`, 'error'); }
};

window.closeDeliveryHistory = () => document.getElementById('deliveryHistoryModal').classList.add('hidden');
window.openDeliveryResolution = function(id) {
  if (!/^\d+$/.test(String(id))) return;
  selectedDeliveryId = String(id);
  deliveryResolutionTitle.textContent = `Resolve uncertain delivery #${selectedDeliveryId}`;
  deliveryResolutionModal.classList.remove('hidden');
};
window.closeDeliveryResolution = () => { selectedDeliveryId = null; deliveryResolutionModal.classList.add('hidden'); };
window.resolveUncertainDelivery = async function(action) {
  const id = selectedDeliveryId;
  if (!id || !['delivered', 'retry', 'archive'].includes(action)) return;
  const descriptions = { delivered: 'confirm this reward was delivered', retry: 'confirm this reward was not delivered and authorize one retry', archive: 'archive this reward from the active queue' };
  if (!window.confirm(`This will ${descriptions[action]}. It cannot be undone from the active queue. Continue?`)) return;
  const statements = {
    delivered: `WITH changed AS (UPDATE dune_airdrop.pending_deliveries SET delivery_state='DELIVERED', is_applied=true, resolution_status='CONFIRMED_DELIVERED', resolution_note='Administrator confirmed delivered.', resolved_at=NOW(), locked_at=NULL, next_attempt_at=NULL, updated_at=NOW() WHERE id=${id}::int AND delivery_state='UNCERTAIN' AND resolution_status IS NULL RETURNING id, request_id), receipt AS (UPDATE dune_airdrop.delivery_receipts r SET status='SUCCESS', status_updated_at=NOW(), failure_reason='Administrator confirmed delivery after investigation.' FROM changed WHERE r.request_id=changed.request_id) INSERT INTO dune_airdrop.delivery_events (delivery_id,state,detail) SELECT id,'DELIVERED','Administrator confirmed delivered after investigation.' FROM changed;`,
    retry: `WITH changed AS (UPDATE dune_airdrop.pending_deliveries SET delivery_state='WAITING_FOR_PLAYER', requires_recovery_approval=false, recovery_approved_at=NOW(), resolution_status=NULL, resolution_note=NULL, resolved_at=NULL, locked_at=NULL, next_attempt_at=NOW(), last_error_code=NULL, last_error_at=NULL, updated_at=NOW() WHERE id=${id}::int AND delivery_state='UNCERTAIN' AND resolution_status IS NULL RETURNING id, request_id), receipt AS (UPDATE dune_airdrop.delivery_receipts r SET status='WAITING_FOR_PLAYER', status_updated_at=NOW(), failure_reason='Administrator confirmed prior delivery did not occur; retry authorized.' FROM changed WHERE r.request_id=changed.request_id) INSERT INTO dune_airdrop.delivery_events (delivery_id,state,detail) SELECT id,'WAITING_FOR_PLAYER','Administrator confirmed undelivered; controlled retry authorized.' FROM changed;`,
    archive: `WITH changed AS (UPDATE dune_airdrop.pending_deliveries SET resolution_status='ARCHIVED', resolution_note='Administrator archived after review.', resolved_at=NOW(), locked_at=NULL, next_attempt_at=NULL, updated_at=NOW() WHERE id=${id}::int AND delivery_state='UNCERTAIN' AND resolution_status IS NULL RETURNING id) INSERT INTO dune_airdrop.delivery_events (delivery_id,state,detail) SELECT id,'ARCHIVED','Administrator archived delivery from the active queue after review.' FROM changed;`
  };
  try { const result = await window.DuneAddon.request('database.execute', { query: statements[action] }); if (Number(result?.rowCount || 0) !== 1) throw new Error('Delivery is no longer eligible for this resolution. Refresh and review it again.'); showToast('Delivery resolution recorded. History was preserved.', 'success'); window.closeDeliveryResolution(); fetchPendingAirdrops(); fetchDeliverySummary(); }
  catch (error) { showToast(`Resolution failed: ${error.message || error}`, 'error'); }
};

async function fetchContainers() {
  if (isSandboxMode) return;
  const tableBody = document.getElementById('lootContainersTableBody');
  if (!tableBody) return;

  try {
    const rawList = await window.DuneAddon.request("database.query", {
      query: `
        SELECT
          i.id::text as id,
          a.class,
          a.owner_account_id
        FROM dune.inventories i
        JOIN dune.actors a ON i.actor_id = a.id
        WHERE a.class ILIKE '%container%' OR a.class ILIKE '%chest%'
        LIMIT 100
      `
    });

    const containers = rawList.rows || rawList || [];

    if (containers.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="4" class="py-4 text-center italic text-slate-500">No containers found.</td></tr>`;
      return;
    }

    tableBody.innerHTML = containers.map(c => {
      const cls = c.class ? c.class.split('/').pop().replace('_C', '') : 'Unknown';
      const isSelected = activeContainerId === c.id;
      const highlight = isSelected ? 'bg-amber-900/30 border-amber-500/50' : '';
      return `
        <tr id="container-row-${escapeHTML(c.id)}" class="container-row border-b border-slate-900/40 hover:bg-slate-900/20 font-mono text-xs cursor-pointer ${highlight}" onclick="window.selectContainer('${escapeHTML(c.id)}')">
          <td class="py-2 text-slate-400 font-bold">${escapeHTML(c.id)}</td>
          <td class="py-2 text-amber-500">${escapeHTML(cls)}</td>
          <td class="py-2 text-slate-300">${escapeHTML(c.owner_account_id || 'Unknown')}</td>
          <td class="py-2 text-center text-slate-500">-</td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    console.error('Failed to load containers:', err);
    tableBody.innerHTML = `<tr><td colspan="4" class="py-4 text-center italic text-rose-500">Error: ${escapeHTML(err.message)}</td></tr>`;
  }
}


// --- UI Toasts ---
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `pointer-events-auto flex items-center gap-2 px-4 py-3 rounded-lg border font-mono text-xs shadow-lg transition-all duration-300 transform translate-y-2 opacity-0`;

  if (type === 'success') {
    toast.className += ' bg-slate-900 border-emerald-500/30 text-emerald-400';
  } else if (type === 'error') {
    toast.className += ' bg-slate-900 border-rose-500/30 text-rose-400';
  } else {
    toast.className += ' bg-slate-900 border-amber-500/30 text-amber-400';
  }

  const icon = type === 'success' ? '✅' : (type === 'error' ? '❌' : '⚠️');
  toast.innerHTML = `<span>${icon}</span> <span class="flex-1">${escapeHTML(message)}</span>`;

  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.remove('translate-y-2', 'opacity-0');
  }, 10);

  setTimeout(() => {
    toast.classList.add('translate-y-2', 'opacity-0');
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 4000);
}

// --- Mock Sandbox Loader ---
function loadMockData() {
  diagnosticsTableBody.innerHTML = `
    <tr class="border-b border-slate-900/40 font-mono text-xs">
      <td class="py-2 text-slate-300">PlayerOne</td>
      <td class="py-2 text-slate-400">42m / 60m</td>
      <td class="py-2 text-slate-400">18m left</td>
      <td class="py-2 text-right text-green-500 font-bold">COMPLETED</td>
    </tr>
    <tr class="border-b border-slate-900/40 font-mono text-xs">
      <td class="py-2 text-slate-300">Nalita</td>
      <td class="py-2 text-slate-400">59m / 60m</td>
      <td class="py-2 text-slate-400">1m left</td>
      <td class="py-2 text-right text-slate-600">PENDING</td>
    </tr>
  `;

  pendingAirdropsTableBody.innerHTML = `
    <tr class="border-b border-slate-900/40 font-mono text-xs">
      <td class="py-1.5 text-slate-300">PlayerOne</td>
      <td class="py-1.5 text-amber-500 font-bold">StandardSword</td>
      <td class="py-1.5 text-right text-slate-300 font-bold">1</td>
    </tr>
  `;
}

// Globals exports
window.handleSaveAllSettings = handleSaveAllSettings;
window.handleInitializeSchema = handleInitializeSchema;
window.showToast = showToast;

window.testResetDaily = async function(characterId) {
  try {
    const safeCharacterId = String(characterId);
    if (!/^[0-9]+$/.test(safeCharacterId)) throw new Error('Invalid character ID');
    await window.DuneAddon.request("database.execute", {
      query: `UPDATE dune_airdrop.active_playtime
              SET last_login_date = NULL, consecutive_days = 0
              WHERE character_id = ${safeCharacterId}::bigint`
    });
    showToast('Daily streak reset for player!', 'success');
    fetchDiagnostics();
  } catch (err) {
    showToast(`Failed to reset daily: ${err.message}`, 'error');
  }
};

window.testSetWeekly = async function(characterId) {
  try {
    const safeCharacterId = String(characterId);
    if (!/^[0-9]+$/.test(safeCharacterId)) throw new Error('Invalid character ID');
    // 31 in binary is 11111 (5 days)
    await window.DuneAddon.request("database.execute", {
      query: `UPDATE dune_airdrop.active_playtime
              SET weekly_login_mask = 31, last_weekly_claimed_at = NULL
              WHERE character_id = ${safeCharacterId}::bigint`
    });
    showToast('Weekly mask set to 5 days!', 'success');
    fetchDiagnostics();
  } catch (err) {
    showToast(`Failed to set weekly: ${err.message}`, 'error');
  }
};
